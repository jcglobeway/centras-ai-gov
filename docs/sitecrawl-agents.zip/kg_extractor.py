"""
tools/kg_extractor.py
Ollama 로컬 LLM을 사용한 엔티티·관계 추출
"""

import json
import re
import uuid
from typing import Any

from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage, SystemMessage
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential

from agent.state import CrawledPage, KGEntity, KGRelation, KGTriples


KG_SYSTEM_PROMPT = """당신은 웹페이지 텍스트에서 지식 그래프를 구성하는 전문가입니다.
주어진 텍스트를 분석하여 엔티티와 관계를 JSON 형식으로 추출하세요.

규칙:
- 엔티티 타입: Product, Person, Concept, Service, Organization, Feature
- 관계 타입: DESCRIBES, MENTIONS, IS_PART_OF, RELATES_TO, COMPETES_WITH, USES
- 중요하고 구체적인 엔티티만 추출 (일반 단어 제외)
- weight는 관계의 강도 (0.1~1.0)
- 반드시 순수 JSON만 반환, 설명 텍스트 없음
"""

KG_USER_TEMPLATE = """URL: {url}
제목: {title}
페이지 타입: {page_type}

본문 (최대 2000자):
{content}

다음 JSON 구조로만 응답하세요:
{{
  "entities": [
    {{"id": "짧고 고유한 영문 ID", "type": "타입", "name": "이름", "description": "1문장 설명"}}
  ],
  "relations": [
    {{"subject": "entity_id", "predicate": "관계타입", "object": "entity_id", "weight": 0.8}}
  ],
  "page_summary": "핵심 내용 2-3문장",
  "main_topics": ["토픽1", "토픽2", "토픽3"]
}}"""


class KGExtractor:
    """
    로컬 Ollama LLM으로 지식 그래프 추출

    추천 모델:
    - llama3.1:8b   → 속도 우선
    - gemma2:9b     → 한국어 이해 우수
    - qwen2.5:14b   → 품질 우선 (VRAM 여유 필요)
    """

    def __init__(self, model: str = "llama3.1:8b", base_url: str = "http://localhost:11434"):
        self.llm = ChatOllama(
            model=model,
            base_url=base_url,
            temperature=0.1,        # 낮은 temperature로 일관된 JSON 출력
            format="json",          # Ollama JSON 모드 강제
        )
        self._entity_registry: dict[str, str] = {}  # name → id 캐시 (중복 방지)

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    async def extract(self, page: CrawledPage) -> KGTriples:
        """페이지에서 KG 트리플 추출"""

        prompt = KG_USER_TEMPLATE.format(
            url=page.url,
            title=page.title,
            page_type=page.page_type,
            content=page.content[:2000],
        )

        try:
            response = await self.llm.ainvoke([
                SystemMessage(content=KG_SYSTEM_PROMPT),
                HumanMessage(content=prompt),
            ])

            raw = response.content
            data = self._safe_parse_json(raw)
            return self._build_triples(data, page.url)

        except Exception as e:
            logger.warning(f"KG 추출 실패 {page.url}: {e}")
            # 실패 시 최소 정보 반환
            return KGTriples(
                entities=[],
                relations=[],
                page_summary=page.title,
                main_topics=[],
            )

    def _safe_parse_json(self, raw: str) -> dict:
        """LLM 응답에서 JSON 안전 파싱"""
        # 마크다운 코드블록 제거
        raw = re.sub(r"```(?:json)?\s*", "", raw).strip()
        raw = re.sub(r"```\s*$", "", raw).strip()

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # JSON 부분만 추출 시도
            match = re.search(r"\{.*\}", raw, re.DOTALL)
            if match:
                return json.loads(match.group())
            return {"entities": [], "relations": [], "page_summary": "", "main_topics": []}

    def _build_triples(self, data: dict, source_url: str) -> KGTriples:
        """파싱된 dict를 KGTriples 객체로 변환"""
        entities = []
        for e in data.get("entities", []):
            # 중복 엔티티 병합 (같은 이름이면 동일 ID 사용)
            name_key = e.get("name", "").lower()
            if name_key in self._entity_registry:
                eid = self._entity_registry[name_key]
            else:
                eid = e.get("id") or f"ent_{uuid.uuid4().hex[:8]}"
                self._entity_registry[name_key] = eid

            entities.append(KGEntity(
                id=eid,
                name=e.get("name", ""),
                type=e.get("type", "Concept"),
                description=e.get("description", ""),
                source_url=source_url,
            ))

        relations = []
        for r in data.get("relations", []):
            relations.append(KGRelation(
                subject_id=r.get("subject", ""),
                predicate=r.get("predicate", "RELATES_TO"),
                object_id=r.get("object", ""),
                weight=float(r.get("weight", 0.5)),
                source_url=source_url,
            ))

        return KGTriples(
            entities=entities,
            relations=relations,
            page_summary=data.get("page_summary", ""),
            main_topics=data.get("main_topics", []),
        )
