"""
graph/agent_graph.py
LangGraph 기반 자율 탐색 Agent 그래프 정의

노드 구성:
  initialize → crawl_batch → extract_kg → index_vectors
      ↑______________|  (큐가 남아있으면 반복)
                                          ↓
                                      finalize
"""

import asyncio
from datetime import datetime
from typing import Literal

from langgraph.graph import StateGraph, END
from loguru import logger

from agent.state import AgentState, CrawledPage
from tools.crawler import AutonomousCrawler
from tools.kg_extractor import KGExtractor
from tools.indexer import VectorIndexer


# ──────────────────────────────────────────────────────────
# 설정값
# ──────────────────────────────────────────────────────────
BATCH_SIZE = 5          # 한 번에 크롤링할 페이지 수
OLLAMA_MODEL = "llama3.1:8b"


# ──────────────────────────────────────────────────────────
# 공유 도구 인스턴스 (그래프 수명 동안 재사용)
# ──────────────────────────────────────────────────────────
_crawler: AutonomousCrawler | None = None
_kg_extractor: KGExtractor | None = None
_indexer: VectorIndexer | None = None


def get_tools(state: AgentState):
    global _crawler, _kg_extractor, _indexer
    if _crawler is None:
        _crawler = AutonomousCrawler(
            max_depth=state["max_depth"],
            max_pages=state["max_pages"],
            focus_keywords=state.get("focus_keywords", []),
        )
    if _kg_extractor is None:
        _kg_extractor = KGExtractor(model=OLLAMA_MODEL)
    if _indexer is None:
        _indexer = VectorIndexer()
    return _crawler, _kg_extractor, _indexer


# ══════════════════════════════════════════════════════════
# NODE 1: initialize
# 초기 상태 설정, 시드 URL을 큐에 추가
# ══════════════════════════════════════════════════════════
async def node_initialize(state: AgentState) -> dict:
    logger.info(f"🚀 Agent 시작: {state['seed_url']}")
    return {
        "url_queue": [state["seed_url"]],
        "visited_urls": [],
        "crawled_pages": [],
        "kg_entities": [],
        "kg_relations": [],
        "kg_summaries": [],
        "indexed_chunks": 0,
        "current_depth": 0,
        "pages_crawled": 0,
        "status": "crawling",
        "errors": [],
        "report": {},
    }


# ══════════════════════════════════════════════════════════
# NODE 2: crawl_batch
# URL 큐에서 BATCH_SIZE개 페이지를 병렬 크롤링
# ══════════════════════════════════════════════════════════
async def node_crawl_batch(state: AgentState) -> dict:
    crawler, _, _ = get_tools(state)

    queue = state["url_queue"]
    visited = set(state["visited_urls"])
    batch = []

    # 큐에서 방문 안 한 URL BATCH_SIZE개 추출
    for url in queue:
        if url not in visited and len(batch) < BATCH_SIZE:
            batch.append(url)

    # 남은 큐 (이번 배치 제외)
    remaining_queue = [u for u in queue if u not in batch]

    logger.info(f"📄 크롤링 배치: {len(batch)}개 | 남은 큐: {len(remaining_queue)}개")

    # 병렬 크롤링
    async with crawler:
        tasks = [
            crawler.crawl_page(url, depth=state["current_depth"])
            for url in batch
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    # 결과 처리
    new_pages = []
    new_links = []
    errors = []
    content_hashes = set()

    for url, result in zip(batch, results):
        if isinstance(result, Exception):
            errors.append(f"크롤링 오류 {url}: {result}")
            continue
        if result is None:
            continue

        # 중복 콘텐츠 제거
        if result.content_hash in content_hashes:
            logger.debug(f"중복 콘텐츠 스킵: {url}")
            continue
        content_hashes.add(result.content_hash)

        new_pages.append(result)
        # 새 링크 큐에 추가 (depth 제한 확인)
        if result.depth < state["max_depth"]:
            prioritized = crawler.prioritize_queue(
                result.links, visited | set(batch), url
            )
            new_links.extend(prioritized[:20])  # 페이지당 최대 20개 링크

    # 중복 없이 큐 확장
    seen = set(remaining_queue)
    unique_new_links = []
    for link in new_links:
        if link not in seen and link not in visited:
            seen.add(link)
            unique_new_links.append(link)

    logger.info(f"✅ 수집 완료: {len(new_pages)}개 페이지 | 신규 링크: {len(unique_new_links)}개")

    return {
        "crawled_pages": new_pages,
        "visited_urls": batch,                          # 방문 완료로 추가
        "url_queue": remaining_queue + unique_new_links,
        "pages_crawled": state["pages_crawled"] + len(new_pages),
        "errors": errors,
        "status": "extracting",
    }


# ══════════════════════════════════════════════════════════
# NODE 3: extract_kg
# 이번 배치 페이지들에서 KG 추출
# ══════════════════════════════════════════════════════════
async def node_extract_kg(state: AgentState) -> dict:
    _, kg_extractor, _ = get_tools(state)

    # 이번 배치 = 최근 크롤된 페이지들
    batch_size = min(BATCH_SIZE, len(state["crawled_pages"]))
    recent_pages = state["crawled_pages"][-batch_size:]

    logger.info(f"🧠 KG 추출: {len(recent_pages)}개 페이지")

    tasks = [kg_extractor.extract(page) for page in recent_pages]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    new_entities = []
    new_relations = []
    new_summaries = []

    for page, result in zip(recent_pages, results):
        if isinstance(result, Exception):
            logger.warning(f"KG 추출 실패 {page.url}: {result}")
            continue

        new_entities.extend(result.entities)
        new_relations.extend(result.relations)
        new_summaries.append({
            "url": page.url,
            "title": page.title,
            "summary": result.page_summary,
            "topics": result.main_topics,
        })

    logger.info(f"  → 엔티티: {len(new_entities)}개, 관계: {len(new_relations)}개")

    return {
        "kg_entities": new_entities,
        "kg_relations": new_relations,
        "kg_summaries": new_summaries,
        "status": "indexing",
    }


# ══════════════════════════════════════════════════════════
# NODE 4: index_vectors
# 청킹 + 임베딩 + Qdrant 저장
# ══════════════════════════════════════════════════════════
async def node_index_vectors(state: AgentState) -> dict:
    _, _, indexer = get_tools(state)

    batch_size = min(BATCH_SIZE, len(state["crawled_pages"]))
    recent_pages = state["crawled_pages"][-batch_size:]
    recent_summaries = state["kg_summaries"][-batch_size:]

    # page → kg 매핑 (url 기준)
    kg_by_url = {s["url"]: s for s in recent_summaries}

    total_chunks = 0
    for page in recent_pages:
        # KGTriples 간이 객체 (indexer가 필요한 필드만)
        from agent.state import KGTriples, KGEntity, KGRelation
        kg_summary = kg_by_url.get(page.url, {})

        # 이 페이지의 엔티티만 필터
        page_entities = [
            e for e in state["kg_entities"]
            if e.source_url == page.url
        ]
        page_relations = [
            r for r in state["kg_relations"]
            if r.source_url == page.url
        ]

        kg = KGTriples(
            entities=page_entities,
            relations=page_relations,
            page_summary=kg_summary.get("summary", ""),
            main_topics=kg_summary.get("topics", []),
        )

        chunks = await asyncio.get_event_loop().run_in_executor(
            None, indexer.index_page, page, kg
        )
        total_chunks += chunks

    logger.info(f"🗄️ 인덱싱 완료: {total_chunks}개 청크 저장")

    return {
        "indexed_chunks": state.get("indexed_chunks", 0) + total_chunks,
        "status": "crawling",   # 다음 배치로
    }


# ══════════════════════════════════════════════════════════
# NODE 5: finalize
# 완료 보고서 생성
# ══════════════════════════════════════════════════════════
async def node_finalize(state: AgentState) -> dict:
    # 엔티티 통계
    entity_types: dict[str, int] = {}
    for e in state["kg_entities"]:
        entity_types[e.type] = entity_types.get(e.type, 0) + 1

    # 토픽 빈도
    topic_freq: dict[str, int] = {}
    for s in state["kg_summaries"]:
        for t in s.get("topics", []):
            topic_freq[t] = topic_freq.get(t, 0) + 1
    top_topics = sorted(topic_freq.items(), key=lambda x: x[1], reverse=True)[:10]

    report = {
        "seed_url": state["seed_url"],
        "completed_at": datetime.now().isoformat(),
        "pages_crawled": state["pages_crawled"],
        "pages_indexed": len(state["crawled_pages"]),
        "total_chunks": state.get("indexed_chunks", 0),
        "kg_entities": len(state["kg_entities"]),
        "kg_relations": len(state["kg_relations"]),
        "entity_type_distribution": entity_types,
        "top_topics": top_topics,
        "errors": len(state["errors"]),
    }

    logger.success(f"""
╔══════════════════════════════════════╗
║       Agent 완료 리포트              ║
╠══════════════════════════════════════╣
║ 크롤링 페이지: {report['pages_crawled']:>5}개              ║
║ 벡터 청크:    {report['total_chunks']:>5}개              ║
║ KG 엔티티:    {report['kg_entities']:>5}개              ║
║ KG 관계:      {report['kg_relations']:>5}개              ║
║ 오류:         {report['errors']:>5}개              ║
╚══════════════════════════════════════╝
    """)

    return {"status": "done", "report": report}


# ══════════════════════════════════════════════════════════
# CONDITIONAL EDGE: 계속할지 종료할지 판단
# ══════════════════════════════════════════════════════════
def should_continue(state: AgentState) -> Literal["crawl_batch", "finalize"]:
    # 종료 조건
    if (
        not state["url_queue"]                          # 큐 비었음
        or state["pages_crawled"] >= state["max_pages"] # 최대 페이지 도달
        or state["status"] == "error"                   # 오류
    ):
        logger.info("🏁 크롤링 종료 조건 충족")
        return "finalize"

    return "crawl_batch"


# ══════════════════════════════════════════════════════════
# 그래프 조립
# ══════════════════════════════════════════════════════════
def build_agent_graph() -> StateGraph:
    graph = StateGraph(AgentState)

    # 노드 등록
    graph.add_node("initialize",     node_initialize)
    graph.add_node("crawl_batch",    node_crawl_batch)
    graph.add_node("extract_kg",     node_extract_kg)
    graph.add_node("index_vectors",  node_index_vectors)
    graph.add_node("finalize",       node_finalize)

    # 엣지 연결
    graph.set_entry_point("initialize")
    graph.add_edge("initialize",    "crawl_batch")
    graph.add_edge("crawl_batch",   "extract_kg")
    graph.add_edge("extract_kg",    "index_vectors")

    # 조건부 엣지: 계속 크롤링 or 종료
    graph.add_conditional_edges(
        "index_vectors",
        should_continue,
        {
            "crawl_batch": "crawl_batch",
            "finalize":    "finalize",
        },
    )
    graph.add_edge("finalize", END)

    return graph.compile()
