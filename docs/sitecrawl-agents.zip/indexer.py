"""
tools/indexer.py
KG 메타데이터 포함 벡터 청킹 & Qdrant 저장
로컬 임베딩: sentence-transformers (BAAI/bge-m3 한국어 최적)
"""

import hashlib
import re
import uuid
from dataclasses import dataclass
from typing import Optional

from loguru import logger
from qdrant_client import QdrantClient, AsyncQdrantClient
from qdrant_client.models import (
    Distance, VectorParams, PointStruct,
    Filter, FieldCondition, MatchValue,
)
from sentence_transformers import SentenceTransformer

from agent.state import CrawledPage, KGTriples


# ──────────────────────────────────────────
# 텍스트 청크
# ──────────────────────────────────────────
@dataclass
class TextChunk:
    id: str
    text: str
    source_url: str
    page_title: str
    section_title: str
    chunk_index: int
    page_type: str


# ──────────────────────────────────────────
# 계층형 청커 (섹션 → Sliding Window)
# ──────────────────────────────────────────
class HierarchicalChunker:
    """
    1단계: h2/h3 경계로 섹션 분리
    2단계: 섹션이 너무 크면 sliding window로 재분할
    """

    def __init__(self, chunk_size: int = 512, overlap: int = 64):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk(self, page: CrawledPage) -> list[TextChunk]:
        sections = self._split_by_sections(page.content)
        chunks = []

        for sec_title, sec_text in sections:
            words = sec_text.split()

            if len(words) <= self.chunk_size:
                # 섹션 전체가 청크 크기 이하 → 그대로 사용
                chunks.append(self._make_chunk(
                    sec_text, page, sec_title, len(chunks)
                ))
            else:
                # Sliding Window 분할
                for i in range(0, len(words), self.chunk_size - self.overlap):
                    window = words[i:i + self.chunk_size]
                    if len(window) < 50:  # 너무 짧은 청크 스킵
                        continue
                    chunks.append(self._make_chunk(
                        " ".join(window), page, sec_title, len(chunks)
                    ))

        return chunks

    def _split_by_sections(self, content: str) -> list[tuple[str, str]]:
        """h2/h3 패턴으로 섹션 분리"""
        # 마크다운 스타일 헤딩 또는 짧은 ALL-CAPS 줄 감지
        section_pattern = re.compile(
            r"^(?:#{1,3}\s+.+|[A-Z가-힣][^\n]{5,50})$",
            re.MULTILINE,
        )
        parts = section_pattern.split(content)
        headers = ["(intro)"] + section_pattern.findall(content)

        sections = []
        for header, text in zip(headers, parts):
            text = text.strip()
            if text:
                sections.append((header.strip(), text))

        return sections if sections else [("(full)", content)]

    def _make_chunk(
        self, text: str, page: CrawledPage, section: str, idx: int
    ) -> TextChunk:
        chunk_id = hashlib.md5(f"{page.url}_{idx}_{text[:50]}".encode()).hexdigest()
        return TextChunk(
            id=chunk_id,
            text=text,
            source_url=page.url,
            page_title=page.title,
            section_title=section,
            chunk_index=idx,
            page_type=page.page_type,
        )


# ──────────────────────────────────────────
# 벡터 DB 인덱서
# ──────────────────────────────────────────
class VectorIndexer:
    """
    로컬 임베딩 + Qdrant 저장
    KG 메타데이터를 payload에 포함 → 필터 검색 가능
    """

    COLLECTION_NAME = "kg_knowledge_base"

    def __init__(
        self,
        qdrant_url: str = "http://localhost:6333",
        embedding_model: str = "BAAI/bge-m3",   # 한국어 최적
    ):
        self.client = QdrantClient(url=qdrant_url)
        self.chunker = HierarchicalChunker()

        logger.info(f"임베딩 모델 로딩: {embedding_model}")
        self.embedder = SentenceTransformer(embedding_model)
        self.vector_size = self.embedder.get_sentence_embedding_dimension()

        self._ensure_collection()

    def _ensure_collection(self):
        """Qdrant 컬렉션 생성 (없으면)"""
        existing = [c.name for c in self.client.get_collections().collections]
        if self.COLLECTION_NAME not in existing:
            self.client.create_collection(
                collection_name=self.COLLECTION_NAME,
                vectors_config=VectorParams(
                    size=self.vector_size,
                    distance=Distance.COSINE,
                ),
            )
            logger.info(f"컬렉션 생성: {self.COLLECTION_NAME} (dim={self.vector_size})")

    def index_page(self, page: CrawledPage, kg: KGTriples) -> int:
        """페이지 청킹 → 임베딩 → KG 메타데이터 포함 저장"""
        chunks = self.chunker.chunk(page)
        if not chunks:
            return 0

        texts = [c.text for c in chunks]
        embeddings = self.embedder.encode(texts, batch_size=16, show_progress_bar=False)

        points = []
        for chunk, embedding in zip(chunks, embeddings):
            points.append(PointStruct(
                id=str(uuid.uuid4()),
                vector=embedding.tolist(),
                payload={
                    # ── 기본 정보 ──
                    "text": chunk.text,
                    "url": chunk.source_url,
                    "title": chunk.page_title,
                    "section": chunk.section_title,
                    "chunk_index": chunk.chunk_index,
                    "page_type": chunk.page_type,
                    "chunk_id": chunk.id,

                    # ── KG 메타데이터 (핵심 차별점!) ──
                    "entities": [e.name for e in kg.entities],
                    "entity_types": list({e.type for e in kg.entities}),
                    "main_topics": kg.main_topics,
                    "page_summary": kg.page_summary,

                    # 연결된 페이지들 (KG LINKS_TO 관계)
                    "linked_pages": [
                        r.object_id for r in kg.relations
                        if r.predicate == "LINKS_TO"
                    ],
                },
            ))

        self.client.upsert(collection_name=self.COLLECTION_NAME, points=points)
        logger.debug(f"인덱싱 완료: {page.url} → {len(points)}개 청크")
        return len(points)

    def search(
        self,
        query: str,
        top_k: int = 10,
        filter_entities: Optional[list[str]] = None,
        filter_page_type: Optional[str] = None,
    ) -> list[dict]:
        """벡터 검색 + 선택적 KG 필터"""
        query_vector = self.embedder.encode(query).tolist()

        # 필터 구성
        must_conditions = []
        if filter_entities:
            for ent in filter_entities:
                must_conditions.append(
                    FieldCondition(key="entities", match=MatchValue(value=ent))
                )
        if filter_page_type:
            must_conditions.append(
                FieldCondition(key="page_type", match=MatchValue(value=filter_page_type))
            )

        search_filter = Filter(must=must_conditions) if must_conditions else None

        results = self.client.search(
            collection_name=self.COLLECTION_NAME,
            query_vector=query_vector,
            limit=top_k,
            query_filter=search_filter,
            with_payload=True,
        )

        return [
            {
                "score": r.score,
                "text": r.payload["text"],
                "url": r.payload["url"],
                "title": r.payload["title"],
                "section": r.payload.get("section", ""),
                "entities": r.payload.get("entities", []),
                "topics": r.payload.get("main_topics", []),
                "summary": r.payload.get("page_summary", ""),
            }
            for r in results
        ]
