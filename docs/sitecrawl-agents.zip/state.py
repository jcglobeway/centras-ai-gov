"""
agent/state.py
LangGraph Agent의 핵심 State 정의
그래프의 모든 노드가 이 State를 읽고 씁니다.
"""

from __future__ import annotations
from typing import Annotated, TypedDict, Optional
from dataclasses import dataclass, field
from datetime import datetime
import operator


# ──────────────────────────────────────────
# 크롤링된 페이지 데이터
# ──────────────────────────────────────────
@dataclass
class CrawledPage:
    url: str
    title: str
    content: str                    # 정제된 텍스트
    links: list[str]                # 발견된 내부 링크
    depth: int                      # 루트로부터 깊이
    parent_url: Optional[str]
    page_type: str = "unknown"      # blog / product / doc / faq / etc
    content_hash: str = ""
    crawled_at: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: dict = field(default_factory=dict)


# ──────────────────────────────────────────
# 지식 그래프 트리플
# ──────────────────────────────────────────
@dataclass
class KGEntity:
    id: str
    name: str
    type: str       # Product / Person / Concept / Service / Organization
    description: str = ""
    source_url: str = ""


@dataclass
class KGRelation:
    subject_id: str
    predicate: str  # DESCRIBES / MENTIONS / IS_PART_OF / RELATES_TO / LINKS_TO
    object_id: str
    weight: float = 1.0
    source_url: str = ""


@dataclass
class KGTriples:
    entities: list[KGEntity]
    relations: list[KGRelation]
    page_summary: str
    main_topics: list[str]


# ──────────────────────────────────────────
# LangGraph Agent State
# Annotated[list, operator.add] → 각 노드가 append 방식으로 누적
# ──────────────────────────────────────────
class AgentState(TypedDict):
    # ── 입력 ──
    seed_url: str
    max_depth: int
    max_pages: int
    focus_keywords: list[str]       # 집중 수집할 키워드 (빈 리스트면 전체)

    # ── 크롤링 상태 ──
    url_queue: list[str]            # 방문 예정 URL
    visited_urls: Annotated[list[str], operator.add]   # 방문 완료
    crawled_pages: Annotated[list[CrawledPage], operator.add]

    # ── 지식 그래프 상태 ──
    kg_entities: Annotated[list[KGEntity], operator.add]
    kg_relations: Annotated[list[KGRelation], operator.add]
    kg_summaries: Annotated[list[dict], operator.add]   # {url, summary, topics}

    # ── 벡터 DB 상태 ──
    indexed_chunks: int             # 저장된 청크 수
    embedding_model: str

    # ── Agent 제어 ──
    current_depth: int
    pages_crawled: int
    status: str                     # idle / crawling / extracting / indexing / done / error
    errors: Annotated[list[str], operator.add]

    # ── 최종 결과 ──
    report: dict                    # 완료 후 요약 리포트
