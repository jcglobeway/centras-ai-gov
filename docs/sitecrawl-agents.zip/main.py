"""
main.py
KG-RAG Agent 실행 진입점

사용법:
  # 1. 크롤링 + 인덱싱
  python main.py crawl --url https://example.com --depth 3 --pages 100

  # 2. RAG 질의
  python main.py query --question "이 사이트의 주요 기능은?"

  # 3. 대화형 모드
  python main.py chat
"""

import asyncio
import sys
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import print as rprint
from loguru import logger

from graph.agent_graph import build_agent_graph
from graph.rag_query import KGRAGEngine

console = Console()


# ──────────────────────────────────────────
# 크롤링 실행
# ──────────────────────────────────────────
async def run_crawl(
    seed_url: str,
    max_depth: int = 3,
    max_pages: int = 100,
    focus_keywords: list[str] | None = None,
):
    console.print(Panel(
        f"[bold cyan]🕷️ 자율 탐색 Agent 시작[/]\n"
        f"URL: [yellow]{seed_url}[/]\n"
        f"최대 깊이: {max_depth} | 최대 페이지: {max_pages}",
        title="KG-RAG Agent",
        border_style="cyan",
    ))

    agent = build_agent_graph()

    initial_state = {
        "seed_url": seed_url,
        "max_depth": max_depth,
        "max_pages": max_pages,
        "focus_keywords": focus_keywords or [],
        "url_queue": [],
        "visited_urls": [],
        "crawled_pages": [],
        "kg_entities": [],
        "kg_relations": [],
        "kg_summaries": [],
        "indexed_chunks": 0,
        "embedding_model": "BAAI/bge-m3",
        "current_depth": 0,
        "pages_crawled": 0,
        "status": "idle",
        "errors": [],
        "report": {},
    }

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Agent 실행 중...", total=None)

        # LangGraph 스트리밍 실행
        async for event in agent.astream(initial_state):
            node_name = list(event.keys())[0]
            node_state = event[node_name]

            if node_name == "crawl_batch":
                pages = node_state.get("pages_crawled", 0)
                progress.update(task, description=f"[cyan]크롤링[/] {pages}페이지 완료...")

            elif node_name == "extract_kg":
                entities = len(node_state.get("kg_entities", []))
                progress.update(task, description=f"[green]KG 추출[/] {entities}개 엔티티...")

            elif node_name == "index_vectors":
                chunks = node_state.get("indexed_chunks", 0)
                progress.update(task, description=f"[yellow]벡터 인덱싱[/] {chunks}개 청크...")

            elif node_name == "finalize":
                report = node_state.get("report", {})
                progress.update(task, description="[bold green]완료!")

    # 최종 리포트 출력
    if report:
        _print_report(report)

    return report


def _print_report(report: dict):
    table = Table(title="📊 크롤링 완료 리포트", border_style="green")
    table.add_column("항목", style="bold")
    table.add_column("값", justify="right", style="cyan")

    table.add_row("크롤링 페이지", str(report.get("pages_crawled", 0)))
    table.add_row("벡터 청크", str(report.get("total_chunks", 0)))
    table.add_row("KG 엔티티", str(report.get("kg_entities", 0)))
    table.add_row("KG 관계", str(report.get("kg_relations", 0)))
    table.add_row("오류", str(report.get("errors", 0)))

    console.print(table)

    if topics := report.get("top_topics"):
        console.print("\n[bold]상위 토픽:[/]")
        for topic, count in topics[:5]:
            console.print(f"  • {topic} ({count}회)")


# ──────────────────────────────────────────
# RAG 질의
# ──────────────────────────────────────────
async def run_query(question: str):
    engine = KGRAGEngine()
    result = await engine.query(question)

    console.print(Panel(
        f"[bold]{question}[/]",
        title="❓ 질문",
        border_style="yellow",
    ))

    console.print(Panel(
        result.answer,
        title="💬 답변",
        border_style="green",
    ))

    if result.entities_used:
        console.print(f"\n[dim]사용된 엔티티: {', '.join(result.entities_used[:5])}[/]")
    console.print(f"[dim]검색 전략: {result.search_strategy}[/]")

    console.print("\n[bold]📚 출처:[/]")
    for i, src in enumerate(result.sources[:3], 1):
        console.print(f"  {i}. {src['title']} — [link]{src['url']}[/link]")


# ──────────────────────────────────────────
# 대화형 모드
# ──────────────────────────────────────────
async def run_chat():
    engine = KGRAGEngine()
    console.print(Panel(
        "구축된 지식 베이스에 질문하세요. 종료: [bold]exit[/]",
        title="💬 KG-RAG 대화 모드",
        border_style="cyan",
    ))

    while True:
        try:
            question = console.input("\n[bold cyan]질문>[/] ").strip()
            if question.lower() in ("exit", "quit", "종료"):
                break
            if not question:
                continue

            result = await engine.query(question)
            console.print(Panel(result.answer, border_style="green"))

            for i, src in enumerate(result.sources[:2], 1):
                console.print(f"  [dim]{i}. {src['url']}[/dim]")

        except KeyboardInterrupt:
            break

    console.print("[dim]종료합니다.[/dim]")


# ──────────────────────────────────────────
# CLI 진입점
# ──────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="KG-RAG Agent")
    subparsers = parser.add_subparsers(dest="command")

    # crawl 커맨드
    crawl_parser = subparsers.add_parser("crawl")
    crawl_parser.add_argument("--url",      required=True, help="시작 URL")
    crawl_parser.add_argument("--depth",    type=int, default=3)
    crawl_parser.add_argument("--pages",    type=int, default=100)
    crawl_parser.add_argument("--keywords", nargs="*", default=[])

    # query 커맨드
    query_parser = subparsers.add_parser("query")
    query_parser.add_argument("--question", required=True)

    # chat 커맨드
    subparsers.add_parser("chat")

    args = parser.parse_args()

    if args.command == "crawl":
        asyncio.run(run_crawl(args.url, args.depth, args.pages, args.keywords))
    elif args.command == "query":
        asyncio.run(run_query(args.question))
    elif args.command == "chat":
        asyncio.run(run_chat())
    else:
        parser.print_help()
