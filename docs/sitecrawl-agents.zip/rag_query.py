"""
graph/rag_query.py
구축된 지식 그래프 + 벡터 DB로 RAG 질의응답
하이브리드 검색: 벡터 + KG 필터 + RRF 재순위화
"""

import asyncio
import re
from dataclasses import dataclass

from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage, SystemMessage
from loguru import logger

from tools.indexer import VectorIndexer


# ──────────────────────────────────────────
# RAG 답변 결과
# ──────────────────────────────────────────
@dataclass
class RAGResult:
    answer: str
    sources: list[dict]
    entities_used: list[str]
    search_strategy: str


# ──────────────────────────────────────────
# 질문 분석기
# ──────────────────────────────────────────
class QueryAnalyzer:
    """질문에서 엔티티와 의도를 추출"""

    def __init__(self, llm: ChatOllama):
        self.llm = llm

    async def analyze(self, question: str) -> dict:
        prompt = f"""다음 질문을 분석해서 JSON으로만 응답하세요:

질문: "{question}"

{{
  "entities": ["질문에서 언급된 구체적 명사/엔티티 목록"],
  "intent": "factual / comparative / how-to / exploratory 중 하나",
  "search_type": "local / global 중 하나",
  "keywords": ["검색에 유용한 키워드 목록"]
}}

- local: 특정 엔티티나 주제에 대한 직접 질문
- global: 전체적인 개요나 비교가 필요한 질문"""

        try:
            response = await self.llm.ainvoke([HumanMessage(content=prompt)])
            import json, re
            raw = re.sub(r"```(?:json)?\s*|```", "", response.content).strip()
            return json.loads(raw)
        except Exception:
            return {
                "entities": [],
                "intent": "factual",
                "search_type": "local",
                "keywords": question.split()[:5],
            }


# ──────────────────────────────────────────
# 하이브리드 검색 + RRF
# ──────────────────────────────────────────
def reciprocal_rank_fusion(
    vector_results: list[dict],
    entity_results: list[dict],
    k: int = 60,
) -> list[dict]:
    """
    두 검색 결과를 RRF로 통합
    score = Σ weight / (k + rank)
    """
    scores: dict[str, dict] = {}

    for rank, doc in enumerate(vector_results, 1):
        uid = doc["url"] + doc.get("section", "") + str(doc.get("chunk_index", 0))
        if uid not in scores:
            scores[uid] = {"score": 0.0, "doc": doc}
        scores[uid]["score"] += 0.7 / (k + rank)   # 벡터 검색 가중치 0.7

    for rank, doc in enumerate(entity_results, 1):
        uid = doc["url"] + doc.get("section", "") + str(doc.get("chunk_index", 0))
        if uid not in scores:
            scores[uid] = {"score": 0.0, "doc": doc}
        scores[uid]["score"] += 0.3 / (k + rank)   # 엔티티 필터 가중치 0.3

    return [
        item["doc"]
        for item in sorted(scores.values(), key=lambda x: x["score"], reverse=True)
    ]


# ──────────────────────────────────────────
# RAG 쿼리 엔진
# ──────────────────────────────────────────
class KGRAGEngine:
    """
    지식 그래프 기반 RAG 질의응답 엔진

    사용법:
        engine = KGRAGEngine()
        result = await engine.query("제품의 주요 기능은?")
        print(result.answer)
    """

    RAG_SYSTEM = """당신은 제공된 컨텍스트를 기반으로 정확하게 답변하는 어시스턴트입니다.

규칙:
- 반드시 컨텍스트에 있는 정보만 사용하세요
- 확실하지 않으면 "컨텍스트에 해당 정보가 없습니다"라고 말하세요
- 출처 URL을 답변 마지막에 포함하세요
- 한국어로 답변하세요"""

    def __init__(
        self,
        ollama_model: str = "llama3.1:8b",
        qdrant_url: str = "http://localhost:6333",
    ):
        self.llm = ChatOllama(model=ollama_model, temperature=0.2)
        self.indexer = VectorIndexer(qdrant_url=qdrant_url)
        self.analyzer = QueryAnalyzer(self.llm)

    async def query(self, question: str, top_k: int = 6) -> RAGResult:
        # 1. 질문 분석
        analysis = await self.analyzer.analyze(question)
        entities = analysis.get("entities", [])
        search_type = analysis.get("search_type", "local")

        logger.info(f"🔍 질문 분석: entities={entities}, type={search_type}")

        # 2. 하이브리드 검색
        # 2a. 순수 벡터 검색
        vector_results = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: self.indexer.search(question, top_k=top_k * 2),
        )

        # 2b. KG 엔티티 필터 검색
        entity_results = []
        if entities:
            entity_results = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.indexer.search(
                    question,
                    top_k=top_k,
                    filter_entities=entities[:3],  # 상위 3개 엔티티로 필터
                ),
            )

        # 3. RRF 통합 및 상위 K개 선택
        merged = reciprocal_rank_fusion(vector_results, entity_results)
        top_docs = merged[:top_k]

        # 4. 컨텍스트 구성
        context_parts = []
        for i, doc in enumerate(top_docs, 1):
            context_parts.append(
                f"[{i}] 출처: {doc['url']}\n"
                f"제목: {doc['title']} / 섹션: {doc.get('section', '')}\n"
                f"내용: {doc['text'][:600]}\n"
            )
        context = "\n---\n".join(context_parts)

        # 5. LLM 답변 생성
        user_prompt = f"""컨텍스트:
{context}

질문: {question}

위 컨텍스트를 바탕으로 답변하세요."""

        response = await self.llm.ainvoke([
            SystemMessage(content=self.RAG_SYSTEM),
            HumanMessage(content=user_prompt),
        ])

        # 사용된 엔티티 수집
        all_entities = []
        for doc in top_docs:
            all_entities.extend(doc.get("entities", []))
        unique_entities = list(dict.fromkeys(all_entities))[:10]

        return RAGResult(
            answer=response.content,
            sources=top_docs,
            entities_used=unique_entities,
            search_strategy=f"{search_type} | entities={entities}",
        )
