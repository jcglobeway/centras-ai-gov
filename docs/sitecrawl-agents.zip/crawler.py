"""
tools/crawler.py
Playwright 기반 자율 탐색 크롤러
JavaScript 렌더링 지원, robots.txt 준수, 중복 제거
"""

import asyncio
import hashlib
import re
from urllib.parse import urljoin, urlparse
from typing import Optional

import httpx
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Browser, Page
from loguru import logger

from agent.state import CrawledPage


class RobotsChecker:
    """robots.txt 파싱 및 허용 여부 확인"""

    def __init__(self):
        self._cache: dict[str, list[str]] = {}

    async def is_allowed(self, url: str, user_agent: str = "*") -> bool:
        parsed = urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        robots_url = f"{base}/robots.txt"

        if base not in self._cache:
            try:
                async with httpx.AsyncClient(timeout=5) as client:
                    r = await client.get(robots_url)
                    disallowed = []
                    current_agent = False
                    for line in r.text.splitlines():
                        line = line.strip()
                        if line.lower().startswith("user-agent:"):
                            agent = line.split(":", 1)[1].strip()
                            current_agent = agent in (user_agent, "*")
                        elif current_agent and line.lower().startswith("disallow:"):
                            path = line.split(":", 1)[1].strip()
                            if path:
                                disallowed.append(path)
                    self._cache[base] = disallowed
            except Exception:
                self._cache[base] = []

        path = parsed.path
        return not any(path.startswith(d) for d in self._cache[base])


class ContentExtractor:
    """HTML에서 의미있는 텍스트와 링크 추출"""

    # 제거할 태그
    NOISE_TAGS = ["script", "style", "nav", "footer", "header",
                  "aside", "iframe", "noscript", "svg"]

    # 페이지 타입 판별 패턴
    TYPE_PATTERNS = {
        "blog":    [r"/blog/", r"/post/", r"/article/", r"/news/"],
        "product": [r"/product/", r"/item/", r"/shop/", r"/store/"],
        "doc":     [r"/docs/", r"/guide/", r"/manual/", r"/reference/"],
        "faq":     [r"/faq", r"/help/", r"/support/"],
        "about":   [r"/about", r"/company/", r"/team/"],
    }

    def extract(self, html: str, base_url: str) -> dict:
        soup = BeautifulSoup(html, "lxml")

        # 노이즈 제거
        for tag in self.NOISE_TAGS:
            for el in soup.find_all(tag):
                el.decompose()

        # 제목 추출
        title = ""
        if soup.title:
            title = soup.title.string or ""
        elif soup.find("h1"):
            title = soup.find("h1").get_text(strip=True)

        # 메인 콘텐츠 우선 추출
        main = (
            soup.find("main") or
            soup.find("article") or
            soup.find(id=re.compile(r"content|main|article", re.I)) or
            soup.find("body")
        )
        content = main.get_text(separator="\n", strip=True) if main else ""

        # 연속 공백/빈 줄 정리
        content = re.sub(r"\n{3,}", "\n\n", content)
        content = re.sub(r"[ \t]+", " ", content)

        # 내부 링크 추출
        parsed_base = urlparse(base_url)
        links = []
        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if not href or href.startswith(("#", "mailto:", "tel:", "javascript:")):
                continue
            abs_url = urljoin(base_url, href)
            parsed = urlparse(abs_url)
            # 같은 도메인만
            if parsed.netloc == parsed_base.netloc:
                # 쿼리스트링, 앵커 제거
                clean = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
                links.append(clean)

        # 메타데이터
        og_title = ""
        og_desc = ""
        if og := soup.find("meta", property="og:title"):
            og_title = og.get("content", "")
        if og := soup.find("meta", property="og:description"):
            og_desc = og.get("content", "")

        # 페이지 타입 판별
        page_type = "general"
        for ptype, patterns in self.TYPE_PATTERNS.items():
            if any(re.search(p, base_url) for p in patterns):
                page_type = ptype
                break

        return {
            "title": title.strip(),
            "content": content[:8000],   # 토큰 절약
            "links": list(set(links)),
            "page_type": page_type,
            "metadata": {"og_title": og_title, "og_description": og_desc},
        }


class AutonomousCrawler:
    """
    LangGraph 노드에서 호출되는 자율 탐색 크롤러

    사용법:
        crawler = AutonomousCrawler(max_depth=3, max_pages=100)
        async with crawler:
            page = await crawler.crawl_page(url, depth, parent_url)
            next_urls = crawler.filter_queue(page.links, visited)
    """

    def __init__(
        self,
        max_depth: int = 4,
        max_pages: int = 200,
        concurrency: int = 3,
        delay: float = 1.0,         # 요청 간 딜레이 (초)
        focus_keywords: list[str] | None = None,
    ):
        self.max_depth = max_depth
        self.max_pages = max_pages
        self.concurrency = concurrency
        self.delay = delay
        self.focus_keywords = [k.lower() for k in (focus_keywords or [])]

        self._browser: Optional[Browser] = None
        self._playwright = None
        self._semaphore = asyncio.Semaphore(concurrency)
        self._robots = RobotsChecker()
        self._extractor = ContentExtractor()

    async def __aenter__(self):
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        return self

    async def __aexit__(self, *args):
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    async def crawl_page(
        self,
        url: str,
        depth: int,
        parent_url: Optional[str] = None,
    ) -> Optional[CrawledPage]:
        """단일 페이지 크롤링"""

        # robots.txt 확인
        if not await self._robots.is_allowed(url):
            logger.debug(f"robots.txt 차단: {url}")
            return None

        async with self._semaphore:
            try:
                context = await self._browser.new_context(
                    user_agent="KG-RAG-Bot/1.0 (knowledge graph builder)"
                )
                page: Page = await context.new_page()

                # JS 렌더링 대기
                await page.goto(url, wait_until="networkidle", timeout=15000)
                await asyncio.sleep(0.5)   # 동적 콘텐츠 추가 대기

                html = await page.content()
                await context.close()

                extracted = self._extractor.extract(html, url)
                content_hash = hashlib.md5(extracted["content"].encode()).hexdigest()

                await asyncio.sleep(self.delay)

                return CrawledPage(
                    url=url,
                    title=extracted["title"],
                    content=extracted["content"],
                    links=extracted["links"],
                    depth=depth,
                    parent_url=parent_url,
                    page_type=extracted["page_type"],
                    content_hash=content_hash,
                    metadata=extracted["metadata"],
                )

            except Exception as e:
                logger.warning(f"크롤링 실패 {url}: {e}")
                return None

    def prioritize_queue(
        self,
        urls: list[str],
        visited: set[str],
        current_url: str,
    ) -> list[str]:
        """
        URL 큐 우선순위 정렬
        - 이미 방문한 URL 제외
        - focus_keywords 포함 URL 우선
        - 너무 깊은 경로 뒤로
        """
        new_urls = [u for u in urls if u not in visited and u != current_url]

        def score(url: str) -> float:
            s = 0.0
            url_lower = url.lower()
            # 키워드 매칭 보너스
            for kw in self.focus_keywords:
                if kw in url_lower:
                    s += 2.0
            # 경로 깊이 페널티
            path_depth = len(urlparse(url).path.strip("/").split("/"))
            s -= path_depth * 0.1
            return s

        return sorted(new_urls, key=score, reverse=True)
